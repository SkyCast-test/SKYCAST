const form = document.getElementById("search-form");
const cityInput = document.getElementById("city");
const statusEl = document.getElementById("status");
const resultEl = document.getElementById("result");
const recentEl = document.getElementById("recent");
const locateBtn = document.getElementById("locate");

const $ = (id) => document.getElementById(id);

function setStatus(html, isError = false) {
  statusEl.innerHTML = html;
  statusEl.className = "status" + (isError ? " error" : "");
}

/* ---------- Recent searches (saved in the browser) ---------- */
function getRecent() {
  try { return JSON.parse(localStorage.getItem("skycast_recent")) || []; }
  catch { return []; }
}

function saveRecent(city) {
  const list = [city, ...getRecent().filter((c) => c.toLowerCase() !== city.toLowerCase())].slice(0, 5);
  try { localStorage.setItem("skycast_recent", JSON.stringify(list)); } catch {}
  renderRecent();
}

function renderRecent() {
  recentEl.innerHTML = "";
  getRecent().forEach((city) => {
    const chip = document.createElement("button");
    chip.type = "button";
    chip.className = "chip";
    chip.textContent = city;
    chip.addEventListener("click", () => { cityInput.value = city; loadWeather({ city }); });
    recentEl.appendChild(chip);
  });
}

/* ---------- Fetch + render ---------- */
async function loadWeather({ city, lat, lon }) {
  const params = new URLSearchParams(lat != null ? { lat, lon } : { city });
  resultEl.classList.add("hidden");
  setStatus('<span class="spinner"></span>Fetching weather...');

  try {
    const res = await fetch("/api/weather?" + params.toString());
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Something went wrong.");
    render(data);
    setStatus("");
    if (city) saveRecent(data.city);
  } catch (err) {
    setStatus(err.message, true);
  }
}

function render(d) {
  $("location").textContent = d.location;
  $("icon").textContent = d.icon;
  $("temp").textContent = d.temperature;
  $("desc").textContent = d.description;
  $("feels").textContent = d.feels_like + "°C";
  $("humidity").textContent = d.humidity + "%";
  $("wind").textContent = d.wind + " km/h";
  $("pressure").textContent = d.pressure + " hPa";
  $("sunrise").textContent = d.sunrise;
  $("sunset").textContent = d.sunset;
  $("updated").textContent = d.updated;

  $("forecast").innerHTML = d.forecast.map((f) => `
    <div class="day">
      <div class="d">${f.day}</div>
      <div class="i" title="${f.description}">${f.icon}</div>
      <div class="t"><b>${f.max}°</b> / ${f.min}°</div>
    </div>`).join("");

  resultEl.classList.remove("hidden");
}

/* ---------- Events ---------- */
form.addEventListener("submit", (e) => {
  e.preventDefault();
  const city = cityInput.value.trim();
  if (city) loadWeather({ city });
});

locateBtn.addEventListener("click", () => {
  if (!navigator.geolocation) return setStatus("Geolocation is not supported by your browser.", true);
  setStatus('<span class="spinner"></span>Finding your location...');
  navigator.geolocation.getCurrentPosition(
    (pos) => loadWeather({ lat: pos.coords.latitude, lon: pos.coords.longitude }),
    () => setStatus("Location permission denied. Please search by city name.", true)
  );
});

renderRecent();
loadWeather({ city: "Gwalior" }); // default city on first load
