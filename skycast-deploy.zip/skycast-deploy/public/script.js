/* SkyCast - static version: the browser calls the free Open-Meteo APIs directly
   (no API key, CORS enabled), so it can be hosted on Netlify / GitHub Pages. */
const GEOCODE_URL = "https://geocoding-api.open-meteo.com/v1/search";
const FORECAST_URL = "https://api.open-meteo.com/v1/forecast";
const AIR_URL = "https://air-quality-api.open-meteo.com/v1/air-quality";
const TIMEOUT_MS = 10000;

const form = document.getElementById("search-form");
const cityInput = document.getElementById("city");
const statusEl = document.getElementById("status");
const resultEl = document.getElementById("result");
const recentEl = document.getElementById("recent");
const locateBtn = document.getElementById("locate");
const $ = (id) => document.getElementById(id);

/* WMO weather code -> [description, day icon, night icon] */
const CODES = {
  0: ["Clear Sky", "☀️", "🌙"], 1: ["Mainly Clear", "🌤️", "🌙"], 2: ["Partly Cloudy", "⛅", "☁️"],
  3: ["Overcast", "☁️", "☁️"], 45: ["Fog", "🌫️", "🌫️"], 48: ["Rime Fog", "🌫️", "🌫️"],
  51: ["Light Drizzle", "🌦️", "🌧️"], 53: ["Drizzle", "🌦️", "🌧️"], 55: ["Heavy Drizzle", "🌧️", "🌧️"],
  56: ["Freezing Drizzle", "🌧️", "🌧️"], 57: ["Freezing Drizzle", "🌧️", "🌧️"],
  61: ["Light Rain", "🌦️", "🌧️"], 63: ["Rain", "🌧️", "🌧️"], 65: ["Heavy Rain", "🌧️", "🌧️"],
  66: ["Freezing Rain", "🌧️", "🌧️"], 67: ["Freezing Rain", "🌧️", "🌧️"],
  71: ["Light Snow", "🌨️", "🌨️"], 73: ["Snow", "❄️", "❄️"], 75: ["Heavy Snow", "❄️", "❄️"],
  77: ["Snow Grains", "❄️", "❄️"], 80: ["Rain Showers", "🌦️", "🌧️"], 81: ["Rain Showers", "🌧️", "🌧️"],
  82: ["Violent Showers", "⛈️", "⛈️"], 85: ["Snow Showers", "🌨️", "🌨️"], 86: ["Snow Showers", "🌨️", "🌨️"],
  95: ["Thunderstorm", "⛈️", "⛈️"], 96: ["Thunderstorm, Hail", "⛈️", "⛈️"], 99: ["Thunderstorm, Hail", "⛈️", "⛈️"],
};

function describe(code, isDay = true) {
  const [text, day, night] = CODES[code] || ["Unknown", "❔", "❔"];
  return [text, isDay ? day : night];
}

class UserError extends Error {}

function setStatus(text, isError = false, loading = false) {
  statusEl.textContent = "";
  if (loading) {
    const spin = document.createElement("span");
    spin.className = "spinner";
    statusEl.appendChild(spin);
  }
  statusEl.appendChild(document.createTextNode(text));
  statusEl.className = "status" + (isError ? " error" : "");
}

/* ---------- API calls ---------- */
async function getJSON(url) {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), TIMEOUT_MS);
  let res;
  try {
    res = await fetch(url, { signal: ctl.signal });
  } catch (e) {
    if (e.name === "AbortError") throw new UserError("The weather service took too long. Try again.");
    throw new UserError("Could not reach the weather service. Check your internet.");
  } finally {
    clearTimeout(timer);
  }
  if (!res.ok) throw new UserError("The weather service returned an error. Try again shortly.");
  try { return await res.json(); }
  catch { throw new UserError("The weather service sent an unexpected response."); }
}

/* "Paris, France": search the name, use the rest as a hint to pick the match. */
async function geocodeCity(query) {
  const [name, ...rest] = query.split(",");
  const hint = rest.join(",").trim().toLowerCase();
  const params = new URLSearchParams({
    name: name.trim() || query, count: hint ? 10 : 1, language: "en", format: "json",
  });
  const data = await getJSON(`${GEOCODE_URL}?${params}`);
  const results = data.results;
  if (!results || !results.length) throw new UserError(`City "${query}" not found. Check the spelling.`);
  let place = results[0];
  if (hint) {
    const match = results.find((r) =>
      [r.admin1, r.country, r.country_code].some((f) => {
        f = (f || "").toLowerCase();
        return f && (f === hint || (hint.length > 2 && f.includes(hint)));
      }));
    if (match) place = match;
  }
  return { name: place.name, region: place.admin1 || "", country: place.country || "",
           latitude: place.latitude, longitude: place.longitude };
}

async function fetchWeather(lat, lon) {
  const params = new URLSearchParams({
    latitude: lat, longitude: lon,
    current: "temperature_2m,relative_humidity_2m,apparent_temperature,is_day,weather_code,wind_speed_10m,wind_direction_10m,surface_pressure,cloud_cover",
    hourly: "temperature_2m,weather_code,precipitation_probability,visibility,is_day",
    daily: "weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,uv_index_max,precipitation_probability_max",
    timezone: "auto", forecast_days: 7,
  });
  return getJSON(`${FORECAST_URL}?${params}`);
}

async function fetchAir(lat, lon) { // optional: never blocks the page
  try {
    const d = await getJSON(`${AIR_URL}?${new URLSearchParams({ latitude: lat, longitude: lon, current: "us_aqi" })}`);
    return d.current && d.current.us_aqi != null ? Math.round(d.current.us_aqi) : null;
  } catch { return null; }
}

/* ---------- Units + helpers ---------- */
let unit = (() => { try { return localStorage.getItem("skycast_unit") || "C"; } catch { return "C"; } })();
let last = null; // last payload, so unit switch can re-render without refetching
const T = (c) => Math.round(unit === "F" ? c * 9 / 5 + 32 : c);
const W = (k) => Math.round(unit === "F" ? k * 0.621371 : k) + (unit === "F" ? " mph" : " km/h");
const el = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };
const DIRS = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"];
const compass = (deg) => DIRS[Math.round(deg / 45) % 8];
function hour12(iso) { const h = +iso.split("T")[1].slice(0, 2); return `${h % 12 || 12} ${h < 12 ? "AM" : "PM"}`; }

function aqiInfo(a) {
  if (a == null) return ["N/A", ""];
  const l = a <= 50 ? "Good" : a <= 100 ? "Moderate" : a <= 150 ? "Sensitive" : a <= 200 ? "Unhealthy" : a <= 300 ? "Very bad" : "Hazardous";
  return [a, l];
}
function uvLabel(u) { return u < 3 ? "Low" : u < 6 ? "Moderate" : u < 8 ? "High" : u < 11 ? "Very high" : "Extreme"; }

function themeFor(code, isDay) {
  if (code >= 95) return "storm";
  if ((code >= 71 && code <= 77) || code === 85 || code === 86) return "snow";
  if ((code >= 51 && code <= 67) || (code >= 80 && code <= 82)) return "rain";
  if (code === 45 || code === 48) return "fog";
  if (code === 3 || code === 2) return "cloudy";
  return isDay ? "clear-day" : "clear-night";
}

function tipFor(p) {
  const t = p.theme;
  if (t === "storm") return "⚡ Thunderstorm risk - stay indoors and avoid open areas.";
  if (t === "rain") return "☂️ Carry an umbrella - rain is around.";
  if (t === "snow") return "🧣 Snowy out there - dress in warm layers.";
  if (t === "fog") return "🚗 Low visibility - drive carefully.";
  if (p.aqi != null && p.aqi > 150) return "😷 Air quality is poor - limit time outdoors.";
  if (p.temperature >= 40) return "🥵 Extreme heat - drink plenty of water and avoid the midday sun.";
  if (p.uv >= 8) return "🧴 Very high UV - use sunscreen and sunglasses.";
  if (p.temperature >= 32) return "💧 Hot day - stay hydrated.";
  if (p.temperature <= 8) return "🧥 Chilly - wear a jacket.";
  if (t === "clear-night") return "🌙 Clear night - nice for a walk or stargazing.";
  return "😊 Pleasant weather - enjoy your day!";
}

/* ---------- Shape data ---------- */
function clock(iso) { // "2026-11-23T06:41" -> "6:41 AM"
  const [h, m] = iso.split("T")[1].split(":").map(Number);
  return `${h % 12 || 12}:${String(m).padStart(2, "0")} ${h < 12 ? "AM" : "PM"}`;
}

function buildPayload(place, data, aqi) {
  const cur = data.current, daily = data.daily, hr = data.hourly;
  const isDay = cur.is_day !== 0;
  const [description, icon] = describe(cur.weather_code, isDay);
  const forecast = daily.time.map((date, i) => {
    const [d_text, d_icon] = describe(daily.weather_code[i], true);
    const [y, mo, d] = date.split("-").map(Number);
    return {
      day: i === 0 ? "Today" : new Date(y, mo - 1, d).toLocaleDateString("en-US", { weekday: "short" }),
      icon: d_icon, description: d_text, rain: daily.precipitation_probability_max[i] || 0,
      max: daily.temperature_2m_max[i], min: daily.temperature_2m_min[i],
    };
  });
  const start = Math.max(0, hr.time.findIndex((t) => t >= cur.time.slice(0, 13) + ":00"));
  const hourly = hr.time.slice(start, start + 24).map((t, k) => ({
    label: k === 0 ? "Now" : hour12(t), icon: describe(hr.weather_code[start + k], hr.is_day[start + k] !== 0)[1],
    temp: hr.temperature_2m[start + k], rain: hr.precipitation_probability[start + k] || 0,
  }));
  const extra = [place.region, place.country].filter(Boolean).join(", ");
  const [datePart] = (cur.time || "").split("T");
  const updated = cur.time
    ? new Date(datePart + "T00:00").toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" }) + ", " + clock(cur.time)
    : new Date().toLocaleString();
  return {
    city: place.name, location: extra ? `${place.name}, ${extra}` : place.name, lat: place.latitude, lon: place.longitude,
    temperature: cur.temperature_2m, feels_like: cur.apparent_temperature, humidity: cur.relative_humidity_2m,
    wind: cur.wind_speed_10m, windDir: compass(cur.wind_direction_10m), pressure: Math.round(cur.surface_pressure || 0),
    clouds: cur.cloud_cover, vis: hr.visibility[start] != null ? Math.round(hr.visibility[start] / 100) / 10 : null,
    uv: Math.round(daily.uv_index_max[0] || 0), rainChance: forecast[0].rain, aqi, description, icon,
    theme: themeFor(cur.weather_code, isDay), sunrise: clock(daily.sunrise[0]), sunset: clock(daily.sunset[0]),
    forecast, hourly, updated,
  };
}

/* ---------- Recent searches (saved in the browser) ---------- */
function getRecent() {
  try { return JSON.parse(localStorage.getItem("skycast_recent")) || []; }
  catch { return []; }
}
function saveRecent(city) {
  const list = [city, ...getRecent().filter((c) => c.toLowerCase() !== city.toLowerCase())].slice(0, 6);
  try { localStorage.setItem("skycast_recent", JSON.stringify(list)); } catch {}
  renderRecent();
}
function renderRecent() {
  recentEl.innerHTML = "";
  getRecent().forEach((city) => {
    const chip = el("button", "chip", city);
    chip.type = "button";
    chip.addEventListener("click", () => { cityInput.value = city; loadWeather({ city }); });
    recentEl.appendChild(chip);
  });
}

/* ---------- Load + render ---------- */
let requestId = 0; // only the latest search may update the page
let lastQuery = { city: "Gwalior" };

async function loadWeather(q) {
  const myId = ++requestId;
  lastQuery = q;
  resultEl.classList.add("hidden");
  setStatus("Fetching weather...", false, true);
  try {
    let place;
    if (q.lat != null) {
      if (!(Math.abs(q.lat) <= 90 && Math.abs(q.lon) <= 180)) throw new UserError("Invalid coordinates.");
      place = { name: "Your Location", region: "", country: "", latitude: q.lat, longitude: q.lon };
    } else {
      place = await geocodeCity(q.city);
    }
    const [data, aqi] = await Promise.all([fetchWeather(place.latitude, place.longitude), fetchAir(place.latitude, place.longitude)]);
    if (myId !== requestId) return; // a newer search started meanwhile
    let payload;
    try { payload = buildPayload(place, data, aqi); }
    catch { throw new UserError("The weather service sent an unexpected response."); }
    last = payload;
    render(payload);
    setStatus("");
    if (q.city) { saveRecent(payload.city); try { localStorage.setItem("skycast_last", q.city); } catch {} }
  } catch (err) {
    if (myId === requestId) setStatus(err instanceof UserError ? err.message : "Something went wrong. Please try again.", true);
  }
}

function render(d) {
  document.body.className = "t-" + d.theme;
  document.querySelector('meta[name="theme-color"]').content = getComputedStyle(document.body).getPropertyValue("--bg2").trim() || "#0f2457";
  startFx(d.theme);
  $("location").textContent = d.location;
  $("icon").textContent = d.icon;
  $("temp").textContent = T(d.temperature);
  $("tu").textContent = "°" + unit;
  $("unit").textContent = "°" + (unit === "C" ? "F" : "C");
  $("desc").textContent = d.description;
  $("hl").textContent = `H ${T(d.forecast[0].max)}°  ·  L ${T(d.forecast[0].min)}°`;
  $("tip").textContent = tipFor(d);
  $("updated").textContent = d.updated;

  const [aq, aql] = aqiInfo(d.aqi);
  const tiles = [
    ["🌡️ Feels Like", T(d.feels_like) + "°" + unit], ["💧 Humidity", d.humidity + "%"],
    ["💨 Wind", W(d.wind), d.windDir], ["⏲️ Pressure", d.pressure + " hPa"],
    ["☀️ UV Index", d.uv, uvLabel(d.uv)], ["🌧️ Rain Chance", d.rainChance + "%"],
    ["🌫️ Air Quality", aq, aql], ["👁️ Visibility", d.vis != null ? d.vis + " km" : "N/A"],
    ["☁️ Cloud Cover", d.clouds + "%"], ["🌅 Sunrise", d.sunrise], ["🌇 Sunset", d.sunset],
  ];
  const box = $("tiles"); box.textContent = "";
  tiles.forEach(([k, v, s]) => {
    const t = el("div", "tile"); t.append(el("span", "", k));
    const b = el("b", "", v); if (s) b.append(" ", el("small", "", s));
    t.append(b); box.appendChild(t);
  });

  const hr = $("hourly"); hr.textContent = ""; hr.scrollLeft = 0;
  d.hourly.forEach((h) => {
    const c = el("div", "hr"); c.append(el("div", "d", h.label), el("div", "i", h.icon), el("div", "t", T(h.temp) + "°"));
    if (h.rain >= 20) c.append(el("div", "p", "💧" + h.rain + "%"));
    hr.appendChild(c);
  });

  const lo = Math.min(...d.forecast.map((f) => f.min)), hi = Math.max(...d.forecast.map((f) => f.max));
  const fc = $("forecast"); fc.textContent = "";
  d.forecast.forEach((f) => {
    const day = el("div", "day");
    const i = el("div", "i", f.icon); i.title = f.description;
    const bar = el("div", "bar"), fill = document.createElement("i");
    fill.style.left = ((f.min - lo) / (hi - lo || 1)) * 100 + "%";
    fill.style.right = (100 - ((f.max - lo) / (hi - lo || 1)) * 100) + "%";
    bar.appendChild(fill);
    const t = el("div", "t"), b = el("b", "", T(f.max) + "°"); t.append(b, " / " + T(f.min) + "°");
    day.append(el("div", "d", f.day), i, bar, t);
    fc.appendChild(day);
  });
  resultEl.classList.remove("hidden");
}

/* ---------- Weather animation (rain / snow / stars) ---------- */
const fx = $("fx"), ctx = fx.getContext("2d");
let parts = [], raf = 0;
const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
function sizeFx() { fx.width = innerWidth; fx.height = innerHeight; }
addEventListener("resize", sizeFx); sizeFx();
function startFx(theme) {
  cancelAnimationFrame(raf); ctx.clearRect(0, 0, fx.width, fx.height);
  const kind = { rain: "rain", storm: "rain", snow: "snow", "clear-night": "star" }[theme];
  if (!kind || reduce) return;
  const n = innerWidth < 600 ? 50 : 100;
  parts = Array.from({ length: n }, () => ({ x: Math.random() * fx.width, y: Math.random() * fx.height, s: Math.random() + .5, r: Math.random() * 2 + 1 }));
  const tick = (t) => {
    ctx.clearRect(0, 0, fx.width, fx.height);
    ctx.fillStyle = ctx.strokeStyle = kind === "rain" ? "rgba(180,220,255,.5)" : "rgba(255,255,255,.8)";
    parts.forEach((p) => {
      if (kind === "rain") { ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(p.x - 2, p.y + 12 * p.s); ctx.stroke(); p.y += 12 * p.s; p.x -= 1; }
      else if (kind === "snow") { ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, 7); ctx.fill(); p.y += p.s; p.x += Math.sin(t / 900 + p.r); }
      else { ctx.globalAlpha = .4 + .6 * Math.abs(Math.sin(t / 1200 + p.x)); ctx.fillRect(p.x, p.y, p.r, p.r); ctx.globalAlpha = 1; }
      if (p.y > fx.height) { p.y = -10; p.x = Math.random() * fx.width; }
      if (p.x < 0) p.x = fx.width;
    });
    raf = requestAnimationFrame(tick);
  };
  raf = requestAnimationFrame(tick);
}

/* ---------- Events ---------- */
function toast(msg) { const t = el("div", "toast", msg); document.body.appendChild(t); setTimeout(() => t.remove(), 2000); }

form.addEventListener("submit", (e) => {
  e.preventDefault();
  const city = cityInput.value.trim();
  if (city) { cityInput.blur(); loadWeather({ city }); }
});

$("unit").addEventListener("click", () => {
  unit = unit === "C" ? "F" : "C";
  try { localStorage.setItem("skycast_unit", unit); } catch {}
  if (last) render(last);
});
$("refresh").addEventListener("click", (e) => { e.currentTarget.classList.add("spin"); setTimeout(() => e.currentTarget.classList.remove("spin"), 800); loadWeather(lastQuery); });
$("share").addEventListener("click", async () => {
  if (!last) return;
  const text = `Weather in ${last.location}: ${T(last.temperature)}°${unit}, ${last.description} - via SkyCast`;
  try {
    if (navigator.share) await navigator.share({ title: "SkyCast", text, url: location.href });
    else { await navigator.clipboard.writeText(text); toast("Copied to clipboard"); }
  } catch {}
});

locateBtn.addEventListener("click", () => {
  if (!navigator.geolocation) return setStatus("Geolocation is not supported by your browser.", true);
  setStatus("Finding your location...", false, true);
  navigator.geolocation.getCurrentPosition(
    (pos) => loadWeather({ lat: pos.coords.latitude, lon: pos.coords.longitude }),
    (err) => {
      const msgs = {
        1: "Location permission denied. Please search by city name.",
        2: "Your location is unavailable right now. Please search by city name.",
        3: "Finding your location timed out. Please search by city name.",
      };
      setStatus(msgs[err.code] || msgs[2], true);
    },
    { timeout: 10000, maximumAge: 300000 }
  );
});

renderRecent();
let startCity = "Gwalior"; // default city on first load
try { startCity = localStorage.getItem("skycast_last") || startCity; } catch {}
loadWeather({ city: startCity });
